import unittest
from numpy.testing import assert_array_equal, assert_allclose
from io import StringIO, BytesIO
import warnings
from copy import deepcopy, copy
import shutil
import os

import httpretty

from amp_prometheus.prometheus_collection_factory import (ClusterMetricsDiskCollectionFactory,
                                                          ClusterMetricsCollectionFactory,
                                                          TypeStrategy)
from amp_prometheus.prometheus_query import *

class TestPrometheusQuery(unittest.TestCase):

    config = {
        "prom_url"  : "http://aspenmesh.io/test/metrics/{}",  # don't use ? as it will not match
        "metric_url": "http://aspenmesh.io/test/services",
        "creds"     : ("****","****")
    }


    @httpretty.activate
    def testClusterMetricsCollection01(self):

        httpretty.register_uri(
            httpretty.GET,
            self.config["metric_url"],
            body=json.dumps({"data": ["mickey", "mini"]}))

        mickey_data = {"data": {
                "resultType": "matrix",
                "result": [
                    {"metric":
                        {
                            "__name__": "mickey",
                            "job": "one",
                            "instance": "two"
                        },
                        "values": [
                            [1550599468, 0],
                            [1550599469, 1],
                            [1550599470, 2],
                            [1550599471, 0],
                            [1550599472, 1],
                            [1550599473, 2],
                            [1550599474, 0],
                            [1550599475, 1],
                            [1550599476, 2]
                        ]},
                    {"metric":
                        {
                            "__name__": "mickey",
                            "job": "two",
                            "instance": "other two"
                        },
                        "values": [
                            [1550599468, 0],
                            [1550599469, 1],
                            [1550599470, 2],
                            [1550599471, 0],
                            [1550599472, 1],
                            [1550599473, 2],
                            [1550599474, 0],
                            [1550599475, 1],
                            [1550599476, 2]
                        ]},
                ]}}

        mini_data = deepcopy(mickey_data)
        mini_data["data"]["result"][0]["metric"]["__name__"] = "mini"
        mini_data["data"]["result"][1]["metric"]["__name__"] = "mini"
        mini_data["data"]["result"][0]["metric"]["a3"] = "three"
        mini_data["data"]["result"][1]["metric"]["a3"] = "other three"

        httpretty.register_uri(
            httpretty.GET,
            self.config["prom_url"].format("query=mickey"),
            body=json.dumps(mickey_data))

        httpretty.register_uri(
            httpretty.GET,
            self.config["prom_url"].format("query=mini"),
            body=json.dumps(mini_data))

        warnings.filterwarnings(action="ignore",
                                message="unclosed",
                                category=ResourceWarning)

        for x in ClusterMetricsCollectionFactory(self.config, TypeStrategy()).get_cluster_metrics_collection():
            x.query()
            a,d = x.analyze_collection(output=False, plots=False)
            self.assertEqual(len(d) ,2)
            self.assertEqual(a["len"], 2)   # 2 metrics per metric_name
            self.assertTrue(all([d[i]["index"]==i for i in range(len(d))]))

        for x in ClusterMetricsCollectionFactory(self.config, TypeStrategy()).get_cluster_metrics_collection():
            x.query()
            a,d = x.analyze_collection(match={"job":"one"}, output=False, plots=False)
            self.assertEqual(len(d),1)
            self.assertEqual(a["len"], 2)   # 2 metrics per metric_name with job=one
            self.assertTrue(all([d[i]["index"]==i for i in range(len(d))]))

        mc = ClusterMetricsCollectionFactory(self.config, TypeStrategy())
        self.assertEqual(mc.show_metric_prototype(),
"""***************** Available Metrics ****************************
mickey
mini
****************************************************************
########### name = mickey
__name__
    job
    instance
########### name = mini
__name__
    job
    instance
    a3"""
    )

        self.assertEqual(mc.show_metric_prototype(metric_name="mini"),
"""__name__
    job
    instance
    a3"""
    )

    @httpretty.activate
    def testClusterMetricsCollection02(self):

        d_list = [
                            [1550599468, 0],
                            [1550599469, 1],
                            [1550599470, 2],
                            [1550599471, 0],
                            [1550599472, 1],
                            [1550599473, 2],
                            [1550599474, 0],
                            [1550599475, 1]
        ]

        m_data = {
        "m_sum" : {"data": {
                "resultType": "matrix",
                "result": [
                    {"metric":
                        {
                            "__name__": "m_sum",
                            "job": "one",
                            "destination_app": "abc",
                            "source_app": "bcd",
                            "instance": "two"
                        },
                        "values": d_list }
        ]}},
        "m_total" : {"data": {
                "resultType": "matrix",
                "result": [
                    {"metric":
                        {
                            "__name__": "m_total",
                            "job": "two",
                            "destination_app": "abc",
                            "source_app": "bcd",
                            "instance": "other two"
                        },
                        "values": d_list }
        ]}},
        "m_count" : {"data": {
            "resultType": "matrix",
            "result": [
                    {"metric":
                        {
                            "__name__": "m_count",
                            "job": "two",
                            "destination_app": "abc",
                            "source_app": "bcd",
                            "instance": "other two"
                        },
                        "values": d_list }
        ]}},
        "m_bucket" : {"data": {
            "resultType": "matrix",
            "result": [
                    {"metric":
                        {
                            "__name__": "m_bucket",
                            "job": "two",
                            "destination_app": "abc",
                            "source_app": "bcd",
                            "instance": "other two",
                            "le": 1
                        },
                        "values": d_list }
        ]}},
        "m_nodest" : {"data": {
            "resultType": "matrix",
            "result": [
                    {"metric":
                        {
                            "__name__": "m_nodest",
                            "job": "two",
                            "instance": "other two",
                            "le": 1
                        },
                        "values": d_list }
        ]}}}

        type_map = {
            "m_bucket": BucketStrategy,
            "m_sum"   : NodeNotBucketStrategy,
            "m_total" : NodeNotBucketStrategy,
            "m_count" : NodeNotBucketStrategy,
            "m_nodest": GenericStrategy
        }

        httpretty.register_uri(
            httpretty.GET,
            self.config["metric_url"],
            body=json.dumps({"data": list(m_data.keys())}))

        for k,v in m_data.items():
            httpretty.register_uri(
                httpretty.GET,
                self.config["prom_url"].format("query={}".format(k)),
                body=json.dumps(v))

        warnings.filterwarnings(action="ignore",
                                message="unclosed",
                                category=ResourceWarning)

        for x in ClusterMetricsCollectionFactory(self.config, TypeStrategy()).get_cluster_metrics_collection():
            x.query()
            x.analyze_collection(output=False, plots=False)
            assert_array_equal(x.get_item(0).data, np.array(d_list, dtype=float))
            self.assertTrue(isinstance(x.metric_analysis_strategy_obj, type_map[x.metric_name]))


    @httpretty.activate
    def testClusterMetricsCollection04(self):
        # query parameters

        httpretty.register_uri(
            httpretty.GET,
            self.config["metric_url"],
            body=json.dumps({"data": ["mickey"]}))

        mickey_data = {"data": {
                "resultType": "matrix",
                "result": [
                    {"metric":
                        {
                            "__name__": "mickey",
                            "job": "one",
                            "instance": "two"
                        },
                        "values": [
                            [1550599468, 0],
                            [1550599469, 1],
                            [1550599470, 2],
                            [1550599471, 0],
                            [1550599472, 1],
                            [1550599473, 2],
                            [1550599474, 0],
                            [1550599475, 1],
                            [1550599476, 2]
                        ]},
                    {"metric":
                        {
                            "__name__": "mickey",
                            "job": "two",
                            "instance": "other two"
                        },
                        "values": [
                            [1550599468, 0],
                            [1550599469, 1],
                            [1550599470, 2],
                            [1550599471, 0],
                            [1550599472, 1],
                            [1550599473, 2],
                            [1550599474, 0],
                            [1550599475, 1],
                            [1550599476, 2]
                        ]},
                ]}}

        httpretty.register_uri(
            httpretty.GET,
            self.config["prom_url"].format("query=mickey"),
            body=json.dumps(mickey_data))

        warnings.filterwarnings(action="ignore",
                                message="unclosed",
                                category=ResourceWarning)

        mickey_data_q = {"data": {
                "resultType": "matrix",
                "result": [
                    {"metric":
                        {
                            "__name__": "mickey",
                            "job": "two",
                            "instance": "other two"
                        },
                        "values": [
                            [1550599468, 0],
                            [1550599469, 1],
                            [1550599470, 2],
                            [1550599471, 0],
                            [1550599472, 1],
                            [1550599473, 2],
                            [1550599474, 0],
                            [1550599475, 1],
                            [1550599476, 2]
                        ]},
                ]}}

        httpretty.register_uri(
            httpretty.GET,
            self.config["prom_url"].format('query=mickey{job="two"}'),
            body=json.dumps(mickey_data_q))

        warnings.filterwarnings(action="ignore",
                                message="unclosed",
                                category=ResourceWarning)


        qs = {"job":"two"}
        for y in ClusterMetricsCollectionFactory(self.config, TypeStrategy()).get_cluster_metrics_collection():
            y.query(arguments=qs)
            self.assertEqual(len(y),1)
            self.assertEqual(y.metric_name, "mickey")
            self.assertEqual(y.get_item(0).instance, "other two")

    def testMetricsEnsemble01(self):
        # filters set/get
        me = MetricEnsemble(GenericStrategy())
        a = me.get_filter()
        self.assertEqual(a,
"""
FILTER CONFIGURATION:
  {}
  w>=0, metric_type in []
  include=[]
  exclude=[]""")
        me.set_filter(
            match={"a":1},
            w=1,
            metric_type=["a","b"],
            metric_blacklist=["fred","wilma"],
            metric_whitelist=["barney","betty"]
        )
        a = me.get_filter()
        self.assertEqual(a,
"""
FILTER CONFIGURATION:
  {'a': 1}
  w>=1.0, metric_type in ['a', 'b']
  include=['barney', 'betty']
  exclude=['fred', 'wilma']""")


    def testMetricsEnsemble02(self):
        mp= {
                        "__name__": "mickey",
                        "job": "two",
                        "instance": "other two"
                       }
        dlist = [
                    [1550599468, 0],
                    [1550599469, 1],
                    [1550599470, 2],
                    [1550599471, 0],
                    [1550599472, 1],
                    [1550599473, 2],
                    [1550599474, 0],
                    [1550599475, 1],
                    [1550599476, 2]
                ]

        ml = []
        for m in ["dopey", "sleepy", "grumpy"]:
            for i in range(3):
                _mdict = copy(mp)
                _mdict["__name__"] = m
                _mdict["unique"] = i
                ml.append(Metric({"metric": _mdict, "values": dlist}))

        me = MetricEnsemble(GenericStrategy())
        me.append(ml)
        self.assertEqual(len(me), 9)
        self.assertEqual(me.get_item(3).__name__, "sleepy")

        me.set_filter(match={"__name__": "sleepy"})
        me.update_ensemble()
        self.assertEqual(len(me), 3)

        #
        me = MetricEnsemble(GenericStrategy())
        me.append(ml)
        self.assertEqual(len(me), 9)

        me.set_filter(match={"unique": 2})
        me.update_ensemble()
        self.assertEqual(len(me), 3)

        #
        me = MetricEnsemble(GenericStrategy())
        me.append(ml)
        self.assertEqual(len(me), 9)

        me.set_filter(w=1)
        me.update_ensemble()
        self.assertEqual(len(me), 9)

if __name__ == '__main__':
    unittest.main()