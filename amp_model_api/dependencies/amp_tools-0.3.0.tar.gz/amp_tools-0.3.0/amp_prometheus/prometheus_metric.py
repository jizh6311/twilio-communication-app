import datetime
import json
import logging
import sys

import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
from scipy.stats import linregress
from scipy.stats.stats import pearsonr

logging.basicConfig(level=logging.DEBUG, filename="./amp_prometheus.log",
                    format="%(asctime)s %(levelname)s (%(threadName)s) [%(name)s] %(message)s")


class Metric:
    """
    Metric Object: represents the tags and data for a single named metric record.
        - Data extraction tools
        - Metric tags are attributes of the class
    """

    # (amp_premetheus type, prometheus type)
    # TODO: work out a better system
    metric_types = {
        "counter": ("count", "counter"),
        "count": ("count", "counter"),
        "sum": ("sum", "counter"),
        "total": ("sum", "counter"),
        "accumulator": ("sum", "counter"),
        "seconds": ("sum", "counter"),
        "bytes": ("sum", "counter"),
        "requests": ("sum", "counter"),
        "calls": ("sum", "counter"),
        "bucket": ("bucket", "histogram"),
        "summary": ("bucket", "summary"),
        "gauge": ("gauge", "gauge"),
        "meters": ("gauge", "gauge"),
        "score": ("gauge", "gauge"),
        "volts": ("gauge", "gauge"),
        "amperes": ("gauge", "gauge"),
        "celsius": ("gauge", "gauge"),
        "level": ("gauge", "gauge")
    }

    def __init__(self, metric_dict):
        """
        Argument is the metrics dictionary provided as list items in the
        Prometheus query interface.  Must contain 'metric' and either 'value'
        or 'values' keys at top level.

        :param metric_dict:
        """

        if "metric" in metric_dict:
            # convenience accessors
            self.__dict__.update(metric_dict["metric"])
        else:
            logging.error("'metric' key missing from dictionary. Aborting!")
            sys.exit(1)

        self.labels = metric_dict["metric"].keys()

        if "value" in metric_dict:
            self.data = np.array(metric_dict["value"], dtype=float)
        elif "values" in metric_dict:
            self.data = np.array(metric_dict["values"], dtype=float)
        else:
            logging.error("'value(s)' key missing from dictionary. Aborting!")
            sys.exit(1)

        self.metric_type = self.get_metric_type()

        logging.debug("metric {} created with {} keys".format(self.__name__, len(self.labels)))

    def get_metric_type(self):
        """
        Use metric name suffix and data attributes to determine the metric type.
        """
        res = (None, None)
        if hasattr(self, "le"):
            res = self.metric_types["bucket"]
        else:
            suffix = self.__name__.split("_")[-1]
            if suffix in self.metric_types:
                res = self.metric_types.get(suffix, (None, None))
            else:
                logging.info("metric type not determined from metric name ({}) suffix {}".format(self.__name__, suffix))
                v = self.get_diff_values_vector()
                if v is not None and len(v) >= 3 and np.alltrue(v[1:] > 0):
                    res = self.metric_types["sum"]
        return res

    def as_metric_dict(self):
        """
        Recover the metrics dictionary structure that created the object
        """
        return {k: getattr(self, k) for k in self.labels}

    def as_query_dict(self, duration="5m", remove_keys=None):
        """
        Set up a query for the exact same metric, possibly changing the duration
        Returns mn, tuple(dict_tags, string_duration)

        :param duration:
        :param remove_keys:
        :return: metric_name, (query_dict, duration_string)
        """
        d = self.as_metric_dict()
        mn = d["__name__"]
        del d["__name__"]
        if remove_keys is not None:
            for r in remove_keys:
                del d[r]
        # return structure is determined by the 2 elements
        # required by utilities below to make a query to prometheus
        return mn, (d, duration)

    def rebase(self, new_timestamp_vector):
        """
        Return a new metric object with values interpolated to a new time base.
        input should be numpy array of timestamps."

        :param new_timestamp_vector:
        :return: metric object
        """
        if (np.min(new_timestamp_vector) < np.min(self.get_timestamp_vector()) or
                np.max(new_timestamp_vector) > np.max(self.get_timestamp_vector())):
            logging.warning("rebase is extrapolating, cutting values outside of range")
            new_timestamp_vector = new_timestamp_vector[new_timestamp_vector < np.max(self.get_timestamp_vector())]
            new_timestamp_vector = new_timestamp_vector[new_timestamp_vector > np.min(self.get_timestamp_vector())]

        sp = interp1d(self.get_timestamp_vector(), self.get_values_vector(), kind='slinear')
        new_values = sp(new_timestamp_vector)
        new_data = np.array([new_timestamp_vector, new_values]).transpose()
        return Metric({
            "metric": self.as_metric_dict(),
            "values": new_data.tolist()
        })

    def get_timestamp_vector(self):
        """
        Returns the first value in the data tuples as a vector
        (np.array) of raw values (unixtimestamps)

        :return: timestamp vector
        """
        v = self.data.transpose()
        if len(v) == 2:
            return v[0]
        else:
            return None

    def get_values_vector(self):
        """
        Returns the second value in the data tuples as a vector of raw values (floats)

        :return: value vector
        """
        v = self.data.transpose()
        if len(v) == 2:
            return v[1]
        else:
            return None

    def get_diff_values_vector(self):
        """Returns the changes between values with the first value assumped to be 0. This
        keeps the return vector the same size as the input vector"""
        v = self.get_values_vector()
        if isinstance(v, np.ndarray) and len(v) > 1:
            return np.ediff1d(v, to_begin=0)
        else:
            return None

    def get_smooth_diff_values(self, N=5, withtime=True, asdatetime=False, padding=False):
        """
        Returns a smoothed (moving average) of the values vector. New vector length
        is (n+1-N). starting and stopping indexes for the corresponding time vector are
        (int(N/2)) and (n+1-int(N/2).

        :param N: smoothing window size
        :param withtime: return the timestamp vector
        :param asdatetime: Return time vector as datetime objects
        :param padding: Set to true for return vector the same size as input vector
        :return: np.array of diffs
        """
        if not padding:
            _tmp_v = np.convolve(self.get_diff_values_vector(), np.ones((N,)) / N, mode='valid')
        else:
            _tmp_v = np.convolve(self.get_diff_values_vector(), np.ones((N,)) / N, mode='same')
        if withtime:
            _tmp_t = self.get_timestamp_vector()
            if asdatetime:
                _tmp_t = self.get_datetime_vector(v=_tmp_t)
            if not padding:
                return _tmp_v, _tmp_t[int(N / 2):len(_tmp_t) + 1 - int(N / 2)]
            else:
                return _tmp_v, _tmp_t
        else:
            return _tmp_v

    def get_datetime_vector(self, v=None):
        """
        Returns the first value in the data tuples as a vector of python
        datetime values (datetime.datetime objects).

        If a vector is provided, it must be an array of timestamps.
        """
        if v is None:
            v = self.get_timestamp_vector()
        res = np.array([datetime.datetime.fromtimestamp(float(x)) for x in v])
        return res

    def _window(self, start_timestamp=None, end_timestamp=None):
        """
        Return a subset of the metric data specified by the date window. All options are optional.
        When neither start options are selected, the first date in included; likewise with the end
        options

        :param start_timestamp: window start
        :param end_timestamp: window end
        :return: windowed_time_vector, windowed_value_vector
        """
        t = self.get_timestamp_vector()
        mint = start_timestamp if start_timestamp is not None else t[0]
        maxt = end_timestamp if end_timestamp is not None else t[-1]
        idx = ((t >= mint) & (t <= maxt))
        return t[idx], self.get_values_vector()[idx]

    def average_rate(self, start_timestamp=-np.inf, end_timestamp=np.inf):
        """
        Find the average rate of count per time for the given interval or for the entire
        time series.

        :param window:
        :return:
        """
        mint = int(max(start_timestamp, self.get_timestamp_vector()[0]))
        maxt = int(min(end_timestamp, self.get_timestamp_vector()[-1]))
        ty, vy = self._window(start_timestamp=mint, end_timestamp=maxt)
        if len(vy) > 2:
            m, y0, r, p, std = linregress(ty, vy)
            return m, y0
        else:
            logging.warning("vectors don't have enough data points in interval ({}:{}))".format(
                self.__name__, vy))
            return None, None

    def ratio(self, other_metric, start_timestamp=-np.inf, end_timestamp=np.inf):
        """
        Estimate the average derivative of the self metric wrt the other_metric values by windowing
        the data and finding the slope via linear regression. other_metric is rebased to self
        metric if necessary.

        :param other_metric: denominator metric_object
        :param start_timestamp: window start
        :param end_timestamp: window end
        :return: slope, y-intercept
        """
        if self == other_metric:
            mint = int(max(start_timestamp, self.get_timestamp_vector()[0], other_metric.get_timestamp_vector()[0]))
            maxt = int(min(end_timestamp, self.get_timestamp_vector()[-1], other_metric.get_timestamp_vector()[-1]))
            mn = other_metric.rebase(self.get_timestamp_vector())
            tx, vx = mn._window(start_timestamp=mint, end_timestamp=maxt)
            ty, vy = self._window(start_timestamp=mint, end_timestamp=maxt)
            if len(vy) > 2:
                m, y0, r, p, std = linregress(vx, vy)
                return m, y0
            else:
                logging.warning("vectors don't have enough data points in interval ({}|{}:{}))".format(
                    self.__name__, other_metric.__name__, vy))
                return None, None
        else:
            logging.warning("cannot divide metrics with mismatched labels")
            return None, None

    def get_dataframe(self, N=5):
        """Metric data as a pandas dataframe with t, datetime, value, value-diff and smoothed value-diff"""
        # cannot smooth more than the length of the vector
        n = len(self.get_values_vector())
        N = n if N > n else N

        df = pd.DataFrame({
            "timestamp": self.get_timestamp_vector(),
            "datetime": self.get_datetime_vector(),
            "y": self.get_values_vector(),
            "dy": self.get_diff_values_vector(),
            "dy_smooth": self.get_smooth_diff_values(N=N, withtime=False, padding=True)
        })
        # Use only NAs, not infinite values
        df = df.replace([-np.inf, np.inf], np.nan)

        df.set_index(df.timestamp)
        logging.info("created data frame to csv (len = {})".format(len(df)))
        return df

    def dataframe_to_csv(self, fo):
        """
        Given a file name or file object, save a csv of the metric data
        """
        df = self.get_dataframe()
        df.to_csv(fo)
        logging.info("wrote data frame to csv (len = {})".format(len(df)))

    def get_dy_histograms(self, bins=50):
        """
        Histograms of value-diff, value-diff density and cdf

        :param bins:
        :return:
        """
        v = self.get_dataframe().dy.dropna().values
        a, b = np.histogram(v, bins=bins)
        d, e = np.histogram(v, bins=bins, density=True)
        # sum is the probability density for the bucket, so multiply by bucket width
        cdf = np.cumsum(d) * (e[1] - e[0])
        return (a, b), (d, e), cdf

    def get_change_score(self):
        """
        Log of change as a scale of change over the time period.  Maybe replace
        with something better?
        :return: score (float)
        """
        v = self.get_values_vector()
        return np.log(abs(v[0] - v[-1]) + 1)

    def get_pearsonr(self, other_metric):
        dfs = self.get_dataframe()
        dfo = other_metric.get_dataframe()
        t = self.get_timestamp_vector()[:-1]
        ot = other_metric.get_timestamp_vector()[:-1]
        if np.array_equal(t, ot):
            res = pearsonr(dfs.dy.dropna().values, dfo.dy.dropna().values)
        else:
            logging.error("pearson r not evaluated due to unequal time baselines")
            logging.error("try rebasing the vectors before correlation calculation")
            res = (0, 0)
        return res

    def concatenate(self, other_metric):
        if self == other_metric:
            # TODO make this smarter for time gaps
            m = Metric({"metric": {k: getattr(self, k) for k in self.labels}, "values": []})
            # remove overlapping tuples
            m.data = np.unique(np.concatenate((self.data, other_metric.data), axis=0), axis=0)
            logging.info("concatenated metric records (len = {})".format(len(m)))
            return m
        else:
            return None

    def diff(self, other_metric):
        """
        Compare tags and values to another metric object. Show the differences.

        :param other_metric: metric object to compare
        :return: string describing differences between this metric and other metric
        """
        res = []
        om = other_metric.as_metric_dict()
        me = self.as_metric_dict()
        me_k = set(me.keys())
        om_k = set(om.keys())
        all_k = me_k.union(om_k)
        for k in all_k:
            if k in om:
                if k in me:
                    if me[k] == om[k]:
                        continue
                    else:
                        res.append("key = {:30} v_self != v_other {:>30}!={:30}".format(k, me[k], om[k]))
                else:
                    res.append("key = {:30} missing from self".format(k))
            else:
                res.append("key = {:30}                   missing from other".format(k))
        return "\n".join(res)

    def is_match(self, m_dict=None):
        """
        All tag keys and values in m_dicdt must match to get a match to m_dict
        m_dict need to contain all labels and corresponding values.

        :param m_dict:
        :return:
        """
        ret = False
        if m_dict is not None:
            f_rec = 0
            for fk, fv in m_dict.items():
                if fk in self.labels:
                    if getattr(self, fk) == fv:
                        f_rec += 1
                if len(m_dict) == f_rec:
                    ret = True
                    break
        return ret

    def __eq__(self, other_metric):
        """Compare metrics by verifying that the dictionary of labels are
        equal (same keys and values). Data differences or acceptable."""
        return self.as_metric_dict() == other_metric.as_metric_dict()

    def __ne__(self, other_metric):
        return not (self == other_metric)

    def __hash__(self):
        """Use metric as a dictionary key"""
        return hash(self.__repr__())

    def __len__(self):
        return len(self.data)

    def __reduce__(self):
        """Allows object to be pickled and unpickled"""
        return (Metric, ({"metric": self.as_metric_dict(), "values": self.data.tolist()},))

    def __repr__(self):
        return "|".join(["{}={}".format(k, v) for k, v in self.as_metric_dict().items()])

    def __str__(self):
        ret = ["{} = {}".format(k, v) for k, v in self.as_metric_dict().items()]
        ret.append("len(data) = {}".format(len(self.data)))
        return "\n".join(ret)


class MetricEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Metric):
            res = {
                "resultType": "matrix",
                "metric": o.as_metric_dict(),
                "values": o.data.tolist()
            }
        elif isinstance(o, (np.ndarray, np.generic)):
            res = o.tolist()
        return res
