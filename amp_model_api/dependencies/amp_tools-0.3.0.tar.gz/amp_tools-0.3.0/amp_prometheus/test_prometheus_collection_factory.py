import json
import os
import shutil
import unittest
import warnings
from copy import deepcopy

import httpretty
import numpy as np
from amp_prometheus.prometheus_collection_factory import (ClusterMetricsCollectionFactory,
    ClusterMetricsDiskCollectionFactory, TypeStrategy)
from numpy.testing import assert_array_equal


class TestPrometheusCollectionFactory(unittest.TestCase):
    config = {
        "prom_url": "http://aspenmesh.io/test/metrics/{}",  # don't use ? as it will not match
        "metric_url": "http://aspenmesh.io/test/services",
        "creds": ("****", "****")
    }

    @httpretty.activate
    def testClusterMetricsCollectionFactory01(self):
        httpretty.register_uri(
            httpretty.GET,
            self.config["metric_url"],
            body=json.dumps({"data": ["mickey", "mini"]}))

        mickey_data = {"data": {
            "resultType": "matrix",
            "result": [
                {"metric":
                    {
                        "__name__": "mickey",
                        "a1": "one",
                        "a2": "two"
                    },
                    "values": [
                        [1550599468, 0],
                        [1550599469, 1],
                        [1550599470, 2]
                    ]},
                {"metric":
                    {
                        "__name__": "mickey",
                        "a1": "one",
                        "a2": "other two"
                    },
                    "values": [
                        [1550599471, 3],
                        [1550599472, 4],
                        [1550599473, 5]
                    ]},
            ]}}

        mini_data = deepcopy(mickey_data)
        mini_data["data"]["result"][0]["metric"]["__name__"] = "mini"
        mini_data["data"]["result"][1]["metric"]["__name__"] = "mini"
        mini_data["data"]["result"][0]["metric"]["a3"] = "three"
        mini_data["data"]["result"][1]["metric"]["a3"] = "other three"

        httpretty.register_uri(
            httpretty.GET,
            self.config["prom_url"].format("query=mickey"),
            body=json.dumps(mickey_data))

        httpretty.register_uri(
            httpretty.GET,
            self.config["prom_url"].format("query=mini"),
            body=json.dumps(mini_data))

        warnings.filterwarnings(action="ignore",
                                message="unclosed",
                                category=ResourceWarning)

        vm = ClusterMetricsCollectionFactory(self.config, TypeStrategy())
        self.assertEqual(["mickey", "mini"], vm.metric_names)
        self.assertEqual(len(vm), 2)

        self.assertTrue("a1" in vm.prototype_metrics["mickey"])
        self.assertTrue("a2" in vm.prototype_metrics["mickey"])
        self.assertTrue("a3" not in vm.prototype_metrics["mickey"])

        self.assertTrue("a1" in vm.prototype_metrics["mini"])
        self.assertTrue("a2" in vm.prototype_metrics["mini"])
        self.assertTrue("a3" in vm.prototype_metrics["mini"])

        mc = vm.create_metric_collection("mini")
        mc.query()
        self.assertEqual(len(mc), 2)

        m = mc.get_item(0)
        self.assertEqual(m.__name__, "mini")
        assert_array_equal(
            np.array(
                [0, 1, 2],
                dtype=float),
            m.get_values_vector()
        )
        m = mc.get_item(1)
        self.assertEqual(m.__name__, "mini")
        assert_array_equal(
            np.array(
                [3, 4, 5],
                dtype=float),
            m.get_values_vector()
        )

        mc = vm.create_metric_collection("mickey")
        mc.query()
        self.assertEqual(len(mc), 2)
        m = mc.get_item(0)
        self.assertEqual(m.__name__, "mickey")
        assert_array_equal(
            np.array(
                [0, 1, 2],
                dtype=float),
            m.get_values_vector()
        )
        m = mc.get_item(1)
        self.assertEqual(m.__name__, "mickey")
        assert_array_equal(
            np.array(
                [3, 4, 5],
                dtype=float),
            m.get_values_vector()
        )

        a = [x.query() for x in vm.get_cluster_metrics_collection()]
        self.assertEqual(len(a), 2)
        self.assertEqual(len(a[0]), 2)
        self.assertEqual(len(a[1]), 2)

    @httpretty.activate
    def testClusterCollectionFactory02(self):
        # pickle

        httpretty.register_uri(
            httpretty.GET,
            self.config["metric_url"],
            body=json.dumps({"data": ["mickey"]}))

        mickey_data = {"data": {
            "resultType": "matrix",
            "result": [
                {"metric":
                    {
                        "__name__": "mickey",
                        "job": "one",
                        "instance": "two"
                    },
                    "values": [
                        [1550599468, 0],
                        [1550599469, 1],
                        [1550599470, 2],
                        [1550599471, 0],
                        [1550599472, 1],
                        [1550599473, 2],
                        [1550599474, 0],
                        [1550599475, 1],
                        [1550599476, 2]
                    ]},
                {"metric":
                    {
                        "__name__": "mickey",
                        "job": "two",
                        "instance": "other two"
                    },
                    "values": [
                        [1550599468, 0],
                        [1550599469, 1],
                        [1550599470, 2],
                        [1550599471, 0],
                        [1550599472, 1],
                        [1550599473, 2],
                        [1550599474, 0],
                        [1550599475, 1],
                        [1550599476, 2]
                    ]},
            ]}}

        httpretty.register_uri(
            httpretty.GET,
            self.config["prom_url"].format("query=mickey"),
            body=json.dumps(mickey_data))

        warnings.filterwarnings(action="ignore",
                                message="unclosed",
                                category=ResourceWarning)

        scratch_dir = "/tmp/1234"
        if os.path.exists(scratch_dir):
            shutil.rmtree(scratch_dir)
        os.makedirs(scratch_dir)

        for y in ClusterMetricsCollectionFactory(self.config, TypeStrategy()).get_cluster_metrics_collection():
            y.query()
            y.pickle(scratch_dir)

        vm = ClusterMetricsDiskCollectionFactory(self.config, TypeStrategy(), scratch_dir)
        self.assertEqual(vm.metric_names, ["mickey"])
        for x in vm.get_cluster_metrics_collection():
            x.from_pickle(vm.pickle_path, x.metric_name)
            self.assertEqual(len(x), 2)
            self.assertEqual(x.metric_name, "mickey")

        # convenience to keep you from forgetting the metric_name filter
        for x in vm.get_cluster_metrics_collection():
            vm.from_pickle(x)
            self.assertEqual(len(x), 2)
            self.assertEqual(x.metric_name, "mickey")

        shutil.rmtree(scratch_dir)


if __name__ == '__main__':
    unittest.main()
