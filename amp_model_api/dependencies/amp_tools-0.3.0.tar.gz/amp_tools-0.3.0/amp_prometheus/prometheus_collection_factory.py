import datetime
import glob
import json
import logging
import os

import numpy as np
import requests
from amp_prometheus.prometheus_query import MetricCollection, GenericStrategy, NodeNotBucketStrategy, BucketStrategy


logging.basicConfig(level=logging.DEBUG, filename="./amp_prometheus.log",
                    format="%(asctime)s %(levelname)s (%(threadName)s) [%(name)s] %(message)s")


# TODO: rename to MetricsCollectionFactory?
class ClusterMetricsCollectionFactory:

    def __init__(self, config, create_metric_collection_strategy_obj, pickle_path=None):
        if pickle_path is not None:
            self.pickle_path = pickle_path
        else:
            self.pickle_path = "/tmp/cluster_metrics/{}".format(np.random.randint(1000))
        self.config = config
        # function(metric_name) --> MetricCollection object
        self.create_metric_collection_obj = create_metric_collection_strategy_obj
        self.metric_names = self._get_metric_names()
        self.prototype_metrics = self._get_prototype_metrics()
        logging.debug("valid metrics found={}".format(len(self.prototype_metrics)))

    def _get_metric_names(self):
        # TODO replace this double query method with single query functionality form prometheus API?
        #   ...api/v1/labels
        url = self.config["metric_url"]
        logging.debug("url={}".format(url))
        try:
            d = requests.get(url, auth=tuple(self.config["creds"]))
            result = d.json()
        except (UnboundLocalError, json.decoder.JSONDecodeError, requests.RequestException) as e:
            logging.error("error parsing JSON from metrics list request ({})".format(e))
            result = {"data": []}

        logging.debug(str(result)[:100])
        return result["data"]

    def _get_prototype_metrics(self):
        res = {}
        for mc in self._get_cluster_metrics():
            logging.debug("...getting keys for {}".format(mc.metric_name))
            m = mc.query().get_item()
            if m is not None:
                res[m.__name__] = m.labels
            else:
                logging.info("query of metrics collection with name={} returned None metric".format(
                    mc.metric_name))
        return res

    def _get_cluster_metrics(self):
        """
        Internal method, used to collect the prototype metrics as generic collections.
        This method will not create the appropriate analysis objects, only the base
        metric Collections
        """
        for mn in self.metric_names:
            yield MetricCollection(mn, self.config, None)

    def create_metric_collection(self, mn):
        if mn in self.prototype_metrics:
            return self.create_metric_collection_obj.create_metric_collection(mn, self.prototype_metrics[mn], self.config)
        return None

    # TODO rename to ...collections?
    def get_cluster_metrics_collection(self, metric_type=None):
        """Generator of all metrics collections"""
        for mn in self.metric_names:
            res = self.create_metric_collection(mn)
            if res is None:
                continue
            if metric_type is not None and metric_type != res.metric_type[0]:
                continue
            yield res

    def show_metric_prototype(self, metric_name=None):
        """Utility for veiwing the metrics and prototypes"""
        if metric_name is None:
            # display the collection
            ret = str(self)
        else:
            # display the chosen metric
            ret = "\n    ".join(list(self.prototype_metrics[metric_name]))
        return ret

    def __len__(self):
        """This is how many MetricsCollections are yielded by the factory generator."""
        return len(self.metric_names)

    def __str__(self):
        ret = []
        ret.append("***************** Available Metrics ****************************")
        ret.append("\n".join(list(self.metric_names)))
        ret.append("****************************************************************")
        for mn, keys in self.prototype_metrics.items():
            ret.append("########### name = {}".format(mn))
            ret.append("\n    ".join((list(keys))))
        return "\n".join(ret)


# TODO rename to DiskMetricsCollectionFactory?
class ClusterMetricsDiskCollectionFactory(ClusterMetricsCollectionFactory):
    """
    Allows reading and writing to disk with metric_name structure
    that is interchangable with the url query behavior.
    """

    def _get_metric_names(self):
        logging.info("Collecting metric names in path={}".format(self.pickle_path))
        _dirs = glob.glob("{}/*-0.pickle".format(self.pickle_path))
        return [a.split("/")[-1].split("-0")[-2] for a in _dirs]

    def _get_prototype_metrics(self):
        res = {}
        remove = []
        for mc in self._get_cluster_metrics():
            logging.debug("...getting keys for {}".format(mc.metric_name))
            m = mc.from_pickle(self.pickle_path, mc.metric_name).get_item()
            if m is not None:
                res[m.__name__] = m.labels
            else:
                # remove from the name list since we don't have a prototype... why not?
                # original data was collected with a prototype from outside the data collection period
                # so their was an original prototype, but it was not persisted as it was not associated
                # with data.
                remove.append(mc.metric_name)
                logging.info("no metrics objects retrieved for metric collection = {}".format(mc.metric_name))

        # remove metrics without data from list outside the loop since _get_cluster_metrics depends on this list
        for rm in remove:
            self.metric_names.remove(rm)
        return res

    def from_pickle(self, x):
        x.from_pickle(self.pickle_path, x.metric_name)


class TypeStrategy:

    def create_metric_collection(self, metric_name, prototype, config):
        """Determines the right Analysis strategy for each metric type and returns
        the appropriate object"""
        res = None
        if metric_name.endswith("bucket"):
            res = MetricCollection(metric_name, config, BucketStrategy())
        elif metric_name.endswith("sum") or metric_name.endswith("count") or metric_name.endswith("total"):
            if "destination_app" in prototype:
                res = MetricCollection(metric_name, config, NodeNotBucketStrategy())
            else:
                res = MetricCollection(metric_name, config, GenericStrategy())
        else:
            res = MetricCollection(metric_name, config, GenericStrategy())
        return res


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Command line Prometheus Query')
    parser.add_argument('--config', default="../notebooks/configuration.json", help="path to coniguration file")
    parser.add_argument('--env', default="prod", help="name of the environment in the config file")
    parser.add_argument('--output', default="../notebooks/data/date", help="output directory")
    parser.add_argument('--duration', default="1h", help="calculate stats")
    args = parser.parse_args()

    if args.output.endswith("date"):
        opath = args.output.replace("date", datetime.datetime.now().strftime("%Y-%m-%d_%H%M"))
    else:
        opath = args.output

    configurations = json.loads(open(args.config, "r").read())
    config = configurations[args.env]

    vm = ClusterMetricsCollectionFactory(config, TypeStrategy())

    print("*" * 80)
    print("Started: {}   Sending outputs to {}...".format(datetime.datetime.now(), opath))
    print("*" * 80)
    print(vm.show_metric_prototype())

    for x in vm.get_cluster_metrics_collection():
        x.query({}, args.duration)
        x.pickle(opath)
