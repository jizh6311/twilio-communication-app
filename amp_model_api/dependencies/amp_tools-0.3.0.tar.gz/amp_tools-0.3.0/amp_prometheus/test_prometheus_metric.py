import pickle
import unittest
from io import BytesIO, StringIO

from amp_prometheus.prometheus_metric import *
from numpy.testing import assert_allclose, assert_array_equal


class TestPrometheusMetric(unittest.TestCase):

    def testMetric00(self):
        """
        Attempt to construct a Metric with an invalid dictionary to test
        system exit with unworkable inputs.
        """
        try:
            m = Metric({})
        except SystemExit:
            self.assertTrue(True)
        else:
            self.assertTrue(False)
        try:
            m = Metric({"metric": {"a": 1}})
        except SystemExit:
            self.assertTrue(True)
        else:
            self.assertTrue(False)

    def testMetric01(self):
        """
        Test constructor for asignments with behavior for
        "value" vs "values" for the data elements and
        for addition attributes that are not in the constructor
        dictionary.
        """
        mdict = {
            "__name__": "mickey",
            "a1": "one",
            "a2": "two",
            "a3": "three"
        }
        dlist = [
            [1550599468, 0],
            [1550599469, 1],
            [1550599470, 2],
            [1550599471, 2],
            [1550599472, 2],
            [1550599473, 2],
            [1550599474, 3],
            [1550599475, 3],
            [1550599476, 3]
        ]
        m = Metric({"metric": mdict, "values": dlist})
        self.assertEqual(m.__name__, mdict["__name__"])
        self.assertEqual(m.a1, mdict["a1"])
        self.assertEqual(m.a2, mdict["a2"])
        self.assertEqual(m.a3, mdict["a3"])
        assert_array_equal(m.data, np.array(dlist, dtype=float))

        # "value" behavior
        dlist = [1550599468, 0]
        m = Metric({"metric": mdict, "value": dlist})
        self.assertEqual(m.__name__, mdict["__name__"])
        self.assertEqual(m.a1, mdict["a1"])
        self.assertEqual(m.a2, mdict["a2"])
        self.assertEqual(m.a3, mdict["a3"])
        assert_array_equal(m.data, np.array(dlist, dtype=float))

        # variable not in constructor set
        m.not_a_lable = 12
        self.assertFalse("not_a_label" in m.as_metric_dict())

    def testMetric02(self):
        # setters and getters
        dlist = [
            [1550599468, 0],
            [1550599469, 1],
            [1550599470, 2],
            [1550599471, 2],
            [1550599472, 2],
            [1550599473, 2],
            [1550599474, 3],
            [1550599475, 3],
            [1550599476, 3]
        ]

        mdict = {"a1": "one", "__name__": "mickey"}
        m = Metric({"metric": mdict, "values": dlist})
        t = np.array(dlist, dtype=float).transpose()[0]
        assert_array_equal(m.get_timestamp_vector(), t)
        tt = [datetime.datetime.fromtimestamp(x) for x in t]
        assert_array_equal(m.get_datetime_vector(), tt)

        df = m.get_dataframe()
        assert_array_equal(df.timestamp, t)
        assert_array_equal(df.datetime, np.array(tt, dtype='datetime64[ns]'))
        assert_array_equal(df.y, np.array(dlist, dtype=float).transpose()[1])

        dlist1 = [
            [1550599468, 0],
            [1550599469, 1],
            [1550599470, 2]]
        m1 = Metric({"metric": mdict, "values": dlist1})
        df1 = m1.get_dataframe()
        assert_array_equal(df1.timestamp, np.array(dlist1, dtype=float).transpose()[0])
        assert_array_equal(df1.y, np.array(dlist1, dtype=float).transpose()[1])

    def testMetric03(self):
        # equality operators
        dlist = [
            [1550599468, 0],
            [1550599469, 1],
            [1550599470, 2],
            [1550599471, 3],
            [1550599472, 4],
            [1550599473, 5],
            [1550599474, 6],
            [1550599475, 7],
            [1550599476, 8]
        ]
        dlist1 = [
            [1550599473, 5],
            [1550599474, 6],
            [1550599475, 7],
            [1550599476, 8],
            [1550599477, 9],
            [1550599478, 10],
            [1550599479, 11],
            [1550599480, 12]
        ]
        mdict = {"a1": "one", "__name__": "mickey"}
        m1 = Metric({"metric": mdict, "values": dlist})
        m2 = Metric({"metric": mdict, "values": dlist})
        m = m1.concatenate(m2)
        # duplicates
        assert_array_equal(m.get_values_vector(), np.array(list(range(9)), dtype=float))

        # 1 duplicate tuple
        m3 = Metric({"metric": mdict, "values": dlist1})
        m = m1.concatenate(m3)
        assert_array_equal(m.get_values_vector(), np.array(list(range(13)), dtype=float))

        m1.a1 = "two"
        self.assertFalse(m1 == m2)
        self.assertTrue(m1 != m2)
        m = m1.concatenate(m2)
        self.assertIsNone(m)

    def testMetric04(self):
        # Test query parameter outputs
        mdict = {
            "__name__": "mickey",
            "a1": "one",
            "a2": "two",
            "a3": "three"
        }
        dlist = [
            [1550599468, 0],
            [1550599469, 1],
            [1550599470, 2],
            [1550599471, 2],
            [1550599472, 2],
            [1550599473, 2],
            [1550599474, 3],
            [1550599475, 3],
            [1550599476, 3]
        ]
        m = Metric({"metric": mdict, "values": dlist})
        a, b = m.as_query_dict()
        self.assertEqual(a, "mickey")
        self.assertEqual(b[0], {
            "a1": "one",
            "a2": "two",
            "a3": "three"
        })
        self.assertEqual(b[1], "5m")
        a, b = m.as_query_dict("10d")
        self.assertEqual(b[1], "10d")

        a, b = m.as_query_dict("10d", remove_keys=["a1", "a2"])
        self.assertEqual(b[1], "10d")
        self.assertEqual(m.a2, "two")
        self.assertTrue("a3" in b[0])
        self.assertFalse("a2" in b[0])
        self.assertFalse("a1" in b[0])

    def testMetric05(self):
        # test csv output
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        dlist = [
            [1550599468, 0],
            [1550599469, 1],
            [1550599470, 2],
            [1550599471, 2],
            [1550599472, 2],
            [1550599473, 2],
            [1550599474, 3],
            [1550599475, 3],
            [1550599476, 3]
        ]
        m = Metric({"metric": mdict, "values": dlist})
        os = StringIO()
        m.dataframe_to_csv(os)
        text = os.getvalue()
        exp_text = """,timestamp,datetime,y,dy,dy_smooth
0,1550599468.0,2019-02-19 11:04:28,0.0,0.0,0.4
1,1550599469.0,2019-02-19 11:04:29,1.0,1.0,0.4
2,1550599470.0,2019-02-19 11:04:30,2.0,1.0,0.4
3,1550599471.0,2019-02-19 11:04:31,2.0,0.0,0.4
4,1550599472.0,2019-02-19 11:04:32,2.0,0.0,0.4
5,1550599473.0,2019-02-19 11:04:33,2.0,0.0,0.2
6,1550599474.0,2019-02-19 11:04:34,3.0,1.0,0.2
7,1550599475.0,2019-02-19 11:04:35,3.0,0.0,0.2
8,1550599476.0,2019-02-19 11:04:36,3.0,0.0,0.2
"""
        self.assertEqual(text, exp_text)

    def testMetric06(self):
        # test pearson r calculation
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        t = np.arange(1550590000, 1550590020, 1)
        t1 = t + 1

        y0 = np.sin(t)
        y1 = np.cos(t)

        dlist0 = [[a, b] for a, b in zip(t, y0)]
        dlist1 = [[a, b] for a, b in zip(t, y1)]
        dlist2 = [[a, b] for a, b in zip(t1, y1)]

        m0 = Metric({"metric": mdict, "values": dlist0})
        m1 = Metric({"metric": mdict, "values": dlist1})
        m2 = Metric({"metric": mdict, "values": dlist2})
        self.assertEqual(m1.get_pearsonr(m1), (1., 0))
        self.assertEqual(m1.get_pearsonr(m2), (0, 0))
        self.assertEqual(m1.get_pearsonr(m0), (-0.0033365817223347614, 0.9888612511687205))

    def testMatric07(self):
        # test metric diff for differences between metrics labels/values
        mdict0 = {
            "__name__": "mickey",
            "a1": "one"
        }
        mdict1 = {
            "__name__": "mickey",
            "a1": "two"
        }
        mdict2 = {
            "__name__": "mickey",
            "a2": "two"
        }
        dlist = [
            [1550599468, 0],
            [1550599469, 1],
            [1550599470, 2]
        ]
        m0 = Metric({"metric": mdict0, "values": dlist})
        m1 = Metric({"metric": mdict1, "values": dlist})
        m2 = Metric({"metric": mdict2, "values": dlist})

        self.assertEqual(m0.diff(m0), "")
        self.assertTrue(m0.diff(m1).strip().endswith("one!=two"))
        self.assertTrue(m0.diff(m2).strip().endswith("missing from other") or
                        m0.diff(m2).strip().endswith("missing from self"))

    def testMetric08(self):
        # test histograms
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        n = 12
        t = np.arange(1550590000, 1550590000 + n, 1)
        y0 = np.array([i % 3 for i in range(n)])
        dlist0 = [[a, b] for a, b in zip(t, y0)]
        m = Metric({"metric": mdict, "values": dlist0})
        a, b, c = m.get_dy_histograms()

        self.assertTrue(len(a), 2)
        self.assertTrue(len(b), 2)
        self.assertTrue(len(c), 1)

        self.assertEqual(len(a[1]), 50 + 1)
        self.assertTrue(np.array_equal(a[0],
                                       np.array([3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
                                                 0, 0, 0, 0, 0, 0, 0, 8])))
        self.assertTrue(np.array_equal(a[1], b[1]))

    def testMetric09(self):
        # test smoothing
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        n = 11
        t = np.arange(1550590000, 1550590000 + n, 1)
        y0 = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
        dlist0 = [[a, b] for a, b in zip(t, y0)]
        m = Metric({"metric": mdict, "values": dlist0})
        assert_allclose(m.get_diff_values_vector()[2:], np.array(y0[0:n - 2], dtype=float))
        self.assertEqual(m.get_diff_values_vector()[0], 0)
        assert_allclose(m.get_smooth_diff_values(withtime=False),
                        np.array([0.6, 1., 1.4, 2.4, 3.8, 6.2, 10.]))
        assert_allclose(m.get_smooth_diff_values(N=2, withtime=False),
                        np.array([0.5, 0.5, 0.5, 1., 1.5, 2.5, 4., 6.5, 10.5, 17.]))
        assert_allclose(m.get_smooth_diff_values(withtime=False, padding=True),
                        np.array([0.2, 0.4, 0.6, 1., 1.4, 2.4, 3.8, 6.2, 10., 9.4, 8.4]))
        assert_allclose(m.get_smooth_diff_values(withtime=True, padding=True)[0],
                        np.array([0.2, 0.4, 0.6, 1., 1.4, 2.4, 3.8, 6.2, 10., 9.4, 8.4]))
        assert_allclose(m.get_smooth_diff_values(withtime=True, padding=True)[1],
                        np.array(t, dtype=float))
        assert_allclose(m.get_smooth_diff_values(withtime=True, padding=True, asdatetime=True)[0],
                        np.array([0.2, 0.4, 0.6, 1., 1.4, 2.4, 3.8, 6.2, 10., 9.4, 8.4]))
        self.assertEqual(m.get_smooth_diff_values(withtime=True, padding=True, asdatetime=True)[1][0],
                         datetime.datetime.fromtimestamp(t[0]))
        self.assertEqual(m.get_smooth_diff_values(withtime=True, padding=False, asdatetime=True)[1][0],
                         datetime.datetime.fromtimestamp(t[2]))

    def testMetric10(self):
        # test hash
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        dlist = [1, 2]
        m = Metric({"metric": mdict, "values": dlist})
        self.assertEqual(m.__repr__(), "__name__=mickey|a1=one")
        self.assertTrue(abs(hash(m)) > 10000000000000)

    def testMetric11(self):
        # test pickle
        os = BytesIO()
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        dlist = [1, 2]
        m = Metric({"metric": mdict, "values": dlist})
        pickle.dump(m, os)
        os.seek(0)
        n = pickle.load(os)
        self.assertTrue(hasattr(n, "a1"))
        self.assertTrue(hasattr(n, "__name__"))

    def testMetric12(self):
        # test string
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        dlist = [1, 2]
        m = Metric({"metric": mdict, "values": dlist})
        self.assertEqual(str(m),
"""__name__ = mickey
a1 = one
len(data) = 2""")

    def testMetric13(self):
        # test rebase
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        dlist = [[1, 1], [3, 3], [5, 5], [7, 7]]
        rebased_dlist = [[2, 2], [4, 4], [6, 6]]
        nt = np.array(rebased_dlist).transpose()[0]
        m = Metric({"metric": mdict, "values": dlist})
        nm = m.rebase(nt)
        self.assertTrue(m == nm)  # keys are values are equal, data can be different
        assert_array_equal(nm.data.tolist(), rebased_dlist)
        nt = np.array(dlist).transpose()[0] + 0.1
        nm = m.rebase(nt)
        self.assertTrue(m == nm)  # keys are values are equal, data can be different
        assert_allclose(nm.data.tolist(), [[1.1, 1.1], [3.1, 3.1], [5.1, 5.1]])

    def testMetric14(self):
        # ratio metrics
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        dlist0 = [[1, 2], [3, 4], [5, 6], [7, 8]]
        m0 = Metric({"metric": mdict, "values": dlist0})
        slope, inter = m0.ratio(m0)
        self.assertEqual(slope, 1)
        self.assertEqual(inter, 0)

        dlist1 = [[1, 3], [3, 5], [5, 7], [7, 9]]
        m1 = Metric({"metric": mdict, "values": dlist1})
        slope, inter = m0.ratio(m1)
        self.assertEqual(slope, 1)
        self.assertEqual(inter, -1)

        dlist1 = [[1, 3], [3, 5], [5, 7], [7, 9], [9, 11], [11, 13]]
        m1 = Metric({"metric": mdict, "values": dlist1})
        slope, inter = m0.ratio(m1)
        self.assertEqual(slope, 1)
        self.assertEqual(inter, -1)

        mdict1 = {
            "__name__": "mickey",
            "a1": "one",
            "a2": "nope"
        }
        m4 = Metric({"metric": mdict1, "values": dlist1})
        slope, inter = m0.ratio(m4)
        self.assertIsNone(slope)
        self.assertIsNone(inter)

    def testMetric15(self):
        # window
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        dlist = [[1, 1], [2, 2], [3, 3], [4, 4], [5, 5], [6, 6], [7, 7]]
        m = Metric({"metric": mdict, "values": dlist})
        a, b = m._window()
        assert_array_equal(a, np.array(range(1, 8)))
        assert_array_equal(b, np.array(range(1, 8)))

        a, b = m._window(start_timestamp=1.4)
        assert_array_equal(a, np.array(range(2, 8)))
        assert_array_equal(b, np.array(range(2, 8)))

        a, b = m._window(start_timestamp=1.4, end_timestamp=5.3)
        assert_array_equal(a, np.array(range(2, 6)))
        assert_array_equal(b, np.array(range(2, 6)))

        a, b = m._window(start_timestamp=1, end_timestamp=5)
        assert_array_equal(a, np.array(range(1, 6)))
        assert_array_equal(b, np.array(range(1, 6)))

    def testMetric16(self):
        """test of json encoding metrics"""
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        dlist = [[1, 1], [2, 2], [3, 3]]
        m = Metric({"metric": mdict, "values": dlist})

        os = json.dumps(m, cls=MetricEncoder)
        md = json.loads(os)
        self.assertEqual(md["metric"], m.as_metric_dict())

        os = json.dumps(np.ones(10), cls=MetricEncoder)
        self.assertEqual(os, json.dumps(np.ones(10).tolist()))

    def testMetric17(self):
        # test metric type identification
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        dlist = [[1, 1], [2, -2], [3, 3], [4, -4]]
        m = Metric({"metric": mdict, "values": dlist})
        self.assertEqual(m.metric_type, (None, None))
        #
        dlist = [[1, 1], [2, 2], [3, 3], [4, 4]]
        mdict = {
            "__name__": "mickey",
            "le": 1
        }
        m = Metric({"metric": mdict, "values": dlist})
        self.assertEqual(m.metric_type, ("bucket", "histogram"))
        #
        mdict = {
            "__name__": "mickey_count"
        }
        m = Metric({"metric": mdict, "values": dlist})
        self.assertEqual(m.metric_type, ("count", "counter"))
        #
        mdict = {
            "__name__": "mickey_sum"
        }
        m = Metric({"metric": mdict, "values": dlist})
        self.assertEqual(m.metric_type, ("sum", "counter"))
        #
        mdict = {
            "__name__": "mickey_unknown_suffix"
        }
        m = Metric({"metric": mdict, "values": dlist})
        self.assertEqual(m.metric_type, ("sum", "counter"))

    def testMetric18(self):
        # rate metrics
        mdict = {
            "__name__": "mickey",
            "a1": "one"
        }
        dlist0 = [[1, 2], [3, 4], [5, 6], [7, 8]]
        m0 = Metric({"metric": mdict, "values": dlist0})
        slope, inter = m0.average_rate()
        self.assertEqual(slope, 1)
        self.assertEqual(inter, 1)

        slope, inter = m0.average_rate(start_timestamp=3, end_timestamp=7)
        self.assertEqual(slope, 1)
        self.assertEqual(inter, 1)

        slope, inter = m0.average_rate(start_timestamp=3, end_timestamp=4)
        self.assertIsNone(slope)
        self.assertIsNone(inter)


if __name__ == '__main__':
    unittest.main()
