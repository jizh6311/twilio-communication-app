import datetime
import glob
import json
import logging
import os
import pickle
from copy import deepcopy
from urllib.parse import urlencode

import matplotlib
import numpy as np
import networkx as nx
import requests
from amp_prometheus.prometheus_metric import Metric, MetricEncoder

matplotlib.use('Agg')
from matplotlib import pyplot as plt

logging.basicConfig(level=logging.DEBUG, filename="./amp_prometheus.log",
                    format="%(asctime)s %(levelname)s (%(threadName)s) [%(name)s] %(message)s")

class MetricList:

    def pickle(self, path="./data"):
        if not os.path.exists(path):
            os.makedirs(path)
        for i, r in enumerate(self.data):
            with open("{}/{}-{}.pickle".format(path, r.__name__, i), "wb") as of:
                pickle.dump(r, of)

    def from_pickle(self, path="./data", metric_name_filter=""):
        # create the collection from pickled files
        self.data = []
        path_dir = "{}/{}*.pickle".format(path, metric_name_filter)
        logging.debug("walking path = {}".format(path_dir))
        for fp in glob.glob(path_dir):
            logging.info("...reading from pickle file = {}".format(fp))
            with open(fp, "rb") as inf:
                self.data.append(pickle.load(inf, encoding="utf-8"))
        logging.info("read total of {} metrics from pickle files".format(len(self.data)))
        return self

    def analyze_collection(self, match=None, plots=True, output=True, w=0):
        # set up record keeping for metric analysis
        diagnostics = []  # list of dicts, one for every metric
        aggregates = {"len": len(self.data)}  # one set of aggregate values across this metric set

        for index, r in self.get_items(match, w=w):
            # this must be the first record for this iteration
            diagnostics.append({"index": index})
            print("\n########### name = {}".format(r.__name__)) if output else None
            diagnostics[-1]["metric"] = r
            diagnostics[-1]["w"] = r.get_change_score()
            # apply the strategy
            self.metric_analysis_strategy_obj.analyze_metric(r, diagnostics, aggregates, output, plots)
        return aggregates, diagnostics

    def plot_network(self, gg):
        """Aggregate utility to show network structure based on traffic"""
        plt.figure(figsize=(10, 10))
        pos = nx.spring_layout(gg)
        nx.draw(gg, pos, with_labels=True, font_weight='bold')
        nx.draw_networkx_edge_labels(gg, pos)
        plt.show()

    def get_item(self, i=0):
        """
        Return a MatricCollection by position in the list.
        See analyze_collection for index creation.
        """
        if len(self.data) > i and i >= 0:
            return self.data[i]
        else:
            return None

    def get_items(self, match=None, w=None):
        """
        Generator of all metrics or matching metrics in the collection.
        """
        for index, r in enumerate(self.data):
            if match is not None and not r.is_match(match):
                logging.info("no match to filter tag(s), skipping index = {} ({})".format(index, r.__name__))
                continue
            if w is not None and r.get_change_score() < w:
                continue
            yield index, r

    def __len__(self):
        return len(self.data)


# todo Rename to "NamedMetricCollection" or something?
class MetricCollection(MetricList):
    """
    A collection of metrics with the same metric_name value but any combination of tag values.
    This (always?) implies the tag keys are the same for each metric in a collection.

    Implements null metric analysis strategy, use a derived class that overwrites "analyze_metric"
    in most cases.
    """

    def __init__(self, metric_name, config, metric_analysis_strategy_obj):
        # metric_analysis_stragey_obj is an instance of the strategy and
        # implements the method "analyze_metric"
        self.config = config  # this is a url, un, pwd struct
        self.metric_name = metric_name
        self.metric_analysis_strategy_obj = metric_analysis_strategy_obj
        self.data = []
        logging.debug("created metric collect with name = {}".format(self.metric_name))

    def query(self, arguments=None, period=None):
        # build the query
        if arguments is not None:
            args_list = []
            for k, v in arguments.items():
                tilda = ""
                if "|" in v:
                    tilda = "~"
                args_list.append('{}={}"{}"'.format(k, tilda, v))
            args = ",".join(args_list)

        # expand here to support more query options
        if arguments is not None and period is not None:
            q = "{}{{{}}}[{}]".format(self.metric_name, args, period)
        elif arguments is not None:
            q = "{}{{{}}}".format(self.metric_name, args)
        elif period is not None:
            q = "{}[{}]".format(self.metric_name, period)
        else:
            q = "{}".format(self.metric_name)
        logging.debug("q={}".format(q))

        # run the query to retrieve the metrics
        self.data = self._get_collection_data({'query': q}, url_key="prom_url")
        return self

    def _get_collection_data(self, q, url_key="prom_url"):
        url = self.config[url_key].format(urlencode(q))
        logging.debug("url (enc) = {}".format(url))
        logging.info("url (plain) = {}".format(
            self.config["prom_url"].format('{}={}'.format(*list(q.items())[0]))
        ))

        try:
            d = requests.get(url, auth=tuple(self.config["creds"]))
        except requests.RequestException as e:
            logging.error("error getting metrics data ({})".format(e))
        try:
            result = d.json()
        except (UnboundLocalError, json.decoder.JSONDecodeError) as e:
            logging.error("error parsing JSON from metrics data request ({})".format(e))
            result = {"data": {"result": []}}
        logging.debug(str(result)[:200])
        return [Metric(m) for m in result['data']['result']]


#########################################################
# TODO Name?
class MetricEnsemble(MetricList):

    def __init__(self, metric_analysis_strategy_obj):
        self.metric_analysis_strategy_obj = metric_analysis_strategy_obj
        self.data = []
        #
        self.match = {}
        self.w = 0
        self.metric_type = []
        self.metric_whitelist = []
        self.metric_blacklist = []

    def set_filter(self,
                   match=None,
                   w=None,
                   metric_type=None,
                   metric_whitelist=None,
                   metric_blacklist=None):
        if match is not None and isinstance(match, dict):
            self.match = match
        if w is not None:
            self.w = max(0, float(w))
        if metric_type is not None and isinstance(metric_type, list):
            self.metric_type = metric_type
        if metric_whitelist is not None and isinstance(metric_whitelist, list):
            self.metric_whitelist = metric_whitelist
        if metric_blacklist is not None and isinstance(metric_blacklist, list):
            self.metric_blacklist = metric_blacklist

    def get_filter(self):
        res = "\nFILTER CONFIGURATION:\n  {}\n  w>={}, metric_type in {}\n  include={}\n  exclude={}".format(
            self.match,
            self.w,
            self.metric_type,
            self.metric_whitelist,
            self.metric_blacklist)
        return res

    def update_ensemble(self):
        tmp = deepcopy(self.data)
        self.data = []
        self.append(tmp)

    def append(self, metric_list):
        for index, x in enumerate(metric_list):
            if x is None:
                logging.debug("skipping due to metric None (idx={})".format(index))
                continue
            if x.__name__ in self.metric_blacklist:
                logging.debug("skipping due to blacklist (idx={})".format(index))
                continue
            elif len(self.metric_whitelist) > 0 and x.__name__ not in self.metric_whitelist:
                logging.debug("skipping due to not being in non-empty whitelist (idx={})".format(index))
                continue
            s = x.get_change_score()
            if s < self.w:
                logging.debug("skipping due to metric activity {}<{} (idx={})".format(s, self.w, index))
                continue
            if self.match is not None and self.match != {} and not x.is_match(self.match):
                logging.debug("skipping due to metric not matching non-empty match dict (idx={})".format(s, index))
                continue
            if len(self.metric_type) > 0 and x.metric_type not in self.metric_type:
                logging.debug(
                    "skipping due to metric type {} not in non-empty list (idx={})".format(x.metric_type, index))
                continue
            self.data.append(x)


#########################################################
# Analyze Metric Strategies
#########################################################

class NodeNotBucketStrategy:
    def analyze_metric(self, r, diag, agg, output_enabled, plots_enabled):
        print("\n  metric={}".format(r.__repr__())) if output_enabled else None
        print("  change_score={}".format(diag[-1]["w"])) if output_enabled else None
        df = r.get_dataframe()
        diag[-1]["avg_dy"] = df.dy.mean()
        if diag[-1]["w"] > 0:
            diag[-1]["histogram"], diag[-1]["pdf"], diag[-1]["cdf"] = r.get_dy_histograms(bins=50)

            if plots_enabled:
                df.plot(x="datetime", y="y", figsize=[15, 4], color="blue")
                plt.show()
                df.plot(x="datetime", y="dy", figsize=[15, 4], color="red")
                plt.show()
                df.hist("dy", bins=50, figsize=[15, 4])
                plt.show()

            logging.debug("adding nodes and edge (w={})".format(diag[-1]["w"]))
            if "graph" not in agg:
                agg["graph"] = nx.MultiGraph()

            agg["graph"].add_node(r.source_app)
            agg["graph"].add_node(r.destination_app)
            agg["graph"].add_edge(r.source_app,
                                  r.destination_app,
                                  weight=diag[-1]["w"])


class BucketStrategy:
    def analyze_metric(self, r, diag, agg, output_enabled, plots_enabled):
        print("\n  metric={}".format(r.__repr__())) if output_enabled else None
        print("  change_score={}".format(diag[-1]["w"])) if output_enabled else None
        df = r.get_dataframe()
        print(df) if output_enabled else None
        logging.debug("adding histogram bucket {})".format(r.le))
        if "cdf" not in agg:
            agg["cdf"] = {float(r.le): int(df.y.values[-1])}
        else:
            agg["cdf"][float(r.le)] = int(df.y.values[-1])


class GenericStrategy:
    def analyze_metric(self, r, diag, agg, output_enabled, plots_enabled):
        print("\n  metric={}".format(r.__repr__())) if output_enabled else None
        print("  change_score={}".format(diag[-1]["w"])) if output_enabled else None
        df = r.get_dataframe()
        diag[-1]["avg_dy"] = df.dy.mean()

        if diag[-1]["w"] > 0:
            diag[-1]["histogram"], diag[-1]["pdf"], diag[-1]["cdf"] = r.get_dy_histograms(bins=50)
            if plots_enabled:
                df.plot(x="datetime", y="y", figsize=[15, 4], color="blue")
                plt.show()
                df.plot(x="datetime", y="dy", figsize=[15, 4], color="red")
                plt.show()
                df.hist("dy", bins=50, figsize=[15, 4])
                plt.show()


