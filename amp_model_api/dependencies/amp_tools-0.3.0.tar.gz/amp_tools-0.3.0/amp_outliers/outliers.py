#!/usr/bin/env python
# coding: utf-8

import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import minimize_scalar


class Outliers1d:
    """Utilities to detect outliers in 1D distributions"""

    def __init__(self):
        self.algorithms = [
            ("Percentile Outliers", self.percentile, 95),
            ("MAD Outliers", self.mad, 3.5),
            ("IQR Outliers", self.iqr, 1.5),
            ("KDE Outliers", self.kde, 0.5),
            ("Z-Score Outliers", self.z_score, 3)
        ]

    def set_thresholds(self, thresholds_list):
        """
        Set new thresholds for the algorithms.

        Tuple of name, threshold or same format as self.algorithms okay.

        :param thresholds_list:
        :return:
        """
        new_ts = {}
        for x in thresholds_list:
            # make a dictionary from first and last element in tuples
            new_ts[x[0]] = float(x[-1])
        new_algorithms = []
        for y in self.algorithms:
            if y[0] in new_ts:
                new_row = (y[0], y[1], new_ts[y[0]])
            else:
                new_row = y
            new_algorithms.append(new_row)
        self.algorithms = new_algorithms

    @staticmethod
    def mad(data_array, threshold=3.5):
        """
        Returns a boolean array with True if points are outliers and False
        otherwise.

        Parameters:
        -----------
            points : An numobservations by numdimensions array of observations
            thresh : The modified z-score to use as a threshold. Observations with
                a modified z-score (based on the median absolute deviation) greater
                than this value will be classified as outliers.

        Returns:
        --------
            mask : A numobservations-length boolean array.

        References:
        ----------
            Boris Iglewicz and David Hoaglin (1993), "Volume 16: How to Detect and
            Handle Outliers", The ASQC Basic References in Quality Control:
            Statistical Techniques, Edward F. Mykytka, Ph.D., Editor.
        """
        threshold = abs(threshold)
        if len(data_array.shape) == 1:
            data_array = data_array[:,None]
        median = np.median(data_array, axis=0)
        diff = np.sum((data_array - median)**2, axis=-1)
        diff = np.sqrt(diff)
        med_abs_deviation = np.median(diff)
        modified_z_score = 0.6745 * diff / med_abs_deviation
        return modified_z_score > threshold

    @staticmethod
    def percentile(data_array, threshold=95):
        threshold = min(99.9, threshold)
        threshold = max(0.1, threshold)
        diff = (100 - threshold) / 2.0
        minval, maxval = np.percentile(data_array, [diff, 100 - diff])
        return (data_array < minval) | (data_array > maxval)

    @staticmethod
    def iqr(data_array, threshold=1.5):
        # http://colingorrie.github.io/outlier-detection.html
        quartile_1, quartile_3 = np.percentile(data_array, [25, 75])
        iqr = quartile_3 - quartile_1
        lower_bound = quartile_1 - (iqr * threshold)
        upper_bound = quartile_3 + (iqr * threshold)
        return (data_array > upper_bound) | (data_array < lower_bound)

    @staticmethod
    def kde(data_array, threshold=0.5):
        threshold = abs(threshold)
        kernel = stats.gaussian_kde(data_array, bw_method = "scott")
        s = len(data_array) * kernel(data_array)/np.sum(kernel(data_array))
        return s < threshold

    @staticmethod
    def z_score(data_array, threshold=3):
        threshold = abs(threshold)
        mu = np.mean(data_array)
        sig = np.std(data_array)
        return np.abs(data_array - mu)/sig > threshold


class DataSets1d:

    def __init__(self, n=200, window=200, skip=1, n_outliers=20,
             mus=(0.1,0.5), sigs=(0.4,0.4), type='lognormal', outlier_range=(2,10)):
        """

        :param self:
        :param n:
        :param window:
        :param skip:
        :param n_outliers:
        :param mus:
        :param sigs:
        :param type:
        :return:
        """
        self.n = n
        self.window=window
        self.skip = skip
        self.n_outliers = n_outliers
        self.outlier_range = outlier_range
        #
        self.datasets = {}
        for mu, sig in zip(mus, sigs):
            name = "{}-{:.3f}_{:.3f}:{}_{}".format(type, mu, sig, n, n_outliers)
            if type == 'lognormal':
                x = np.random.lognormal(mu, sig, n - n_outliers)
            elif type == 'normal':
                x = np.random.normal(mu, sig, n - n_outliers)
            elif type == 'uniform':
                x = np.random.uniform(mu - sig, mu + sig, n - n_outliers)
            self.datasets[name] = self.time_series(x, mu, sig)

    def time_series(self, data_array, mu, sig):
        """
        Create a log-normal random timeseries of total length n, with mu and sigma as specified.

        This is a generator of windows of data. If window is none, they entire timeseries is returned.

        Outliers are generated, evenly spaced, between the sigma x min and sigma x max and reandomly
        distributed in the data. An outlier mask is returned with the data set.

        :param n:
        :param window:
        :param mu:
        :param sig:
        :param n_outliers:
        :param out_range:
        :return:
        """
        res = []
        if self.window is None:
            self.window = self.n
        if self.skip < 1:
            self.skip = 1
        elif self.skip > self.window:
            # only allow no overlap, not jumps over day... why waste data?
            self.skip = self.window
        x, mask = self.data_array_with_outliers(data_array, mu, sig)
        for i_window, idx in enumerate(range(0, self.n-self.window+1, self.skip)):
            x_w = x[idx: idx+self.window]
            o_m = mask[idx: idx+self.window]
            res.append((i_window, x_w, o_m))
        return res

    def data_array_with_outliers(self, x, mu, sig):
        """
        Randomly insert outliers and return a mask of where they are located.

        :param self:
        :param x:
        :param mu:
        :param sig:
        :param n_outliers:
        :param outlier_range:
        :return:
        """
        _mu = np.mean(x)
        _sig = np.std(x)
        out_low = _mu + min(self.outlier_range)*_sig
        out_high = _mu + max(self.outlier_range)*_sig
        o = np.linspace(out_low, out_high , self.n_outliers)
        # put the outliers on the end so they have index >= len-n_outliers
        # then shuffle the indexes
        xout = np.concatenate([x, o], axis=0)
        shuffle_index = np.arange(len(xout))
        np.random.shuffle(shuffle_index)
        outlier_mask = shuffle_index >= (len(xout) - self.n_outliers)
        return xout[shuffle_index], outlier_mask

class Outliers1dEvaluation:

    def __init__(self):
        pass

    def model_metrics(self, threshold, data_array, outliers_mask, algorithm, w=1.0):
        """

        :param threshold:
        :param data_array:
        :param outliers_mask:
        :param algorithm:
        :return:
        """
        n_outliers = np.sum(np.ones(len(outliers_mask))[outliers_mask])
        n_data = len(data_array) - n_outliers
        #
        xpred = algorithm(data_array, threshold=threshold)

        # True = outlier, x_actual_model
        outout = len(data_array[np.logical_and(xpred, outliers_mask)])
        inin = len(data_array[np.logical_not(np.logical_or(xpred, outliers_mask))])
        outin = n_outliers - outout
        inout = n_data - inin
        if outout == 0:
            P = 0
            R = 0
            F1 = 0
        else:
            P = outout/(outout + inout)
            R = outout/(outout + outin)
            F1 = 2*w*P*R/(P + w*R)
        return P, R, F1, [[outout, outin],[inout, inin]]

    def opt_score(self, threshold, dataset_obj, algorithm):
        res = []
        for i_dataset, (name, dataset_generator) in enumerate(dataset_obj.datasets.items()):
            for i, x, o_m in dataset_generator:
                # 0 = Precision
                # 1 = Recall
                # 2 = F1 (potentially weighted on recall, w=1 is traditional F1 score)
                r = self.model_metrics(threshold, x, o_m, algorithm)
                res.append(-r[2])
        return np.mean(res)

    def optimize_models(self, dataset_obj, algorithms_obj):
        new_algorithms_list = []
        for name, algorithm, threshold in algorithms_obj.algorithms:
            res = minimize_scalar(self.opt_score, args=(dataset_obj, algorithm))
            print("#"*25)
            print(name)
            print("#"*25)
            print(res)
            new_algorithms_list.append((name, algorithm, res.x))
        return new_algorithms_list

    def model_eval(self, dataset_obj, algorithms_obj, include_data=False, dataframe=False):
        metrics = []
        for i_dataset, (data_name, dataset_generator) in enumerate(dataset_obj.datasets.items()):
            for i_window, X, outliers_mask in dataset_generator:
                for name, algorithm, threshold in algorithms_obj.algorithms:
                    p, r, f1, conf = self.model_metrics(threshold, X, outliers_mask, algorithm)
                    metrics.append([i_dataset, i_window,
                                    data_name, name,
                                    dataset_obj.window, dataset_obj.n_outliers,
                                    p, r, f1])
                    if include_data:
                        metrics[-1].extend([X, outliers_mask])
        if dataframe:
            df = pd.DataFrame(metrics, columns=[
                "i_dataset",
                "i_window",
                "data_name",
                "model_name",
                "n",
                "n_outliers",
                "precision",
                "recall",
                "f1"])
            return df
        else:
            return metrics
