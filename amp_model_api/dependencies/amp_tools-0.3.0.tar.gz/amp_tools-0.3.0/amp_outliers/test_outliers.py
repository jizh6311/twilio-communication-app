import unittest
from numpy.testing import assert_array_equal, assert_allclose

from amp_outliers.outliers import *

class TestOutliers(unittest.TestCase):

    def setUp(self):
        self.a = Outliers1d()
        self.d = np.array(
            [18.,1.1503371,-1.00460321,1.07139354,1.59543841,1.18015304,-1.82483212,0.24699652,
            0.51223634,-0.5615576,0.38482699,0.89413678,-0.42196331,0.55118364,1.02002636,-0.38117853,
            -1.16651069,0.10849452,-0.02718603,-18.]
        )
        self.m = np.array(
            [True, False, False, False, False, False, False, False, False,
             False, False, False, False, False, False, False, False, False, False, True]
        )

    def test_mad(self):
        assert_array_equal(self.a.mad(self.d), self.m)

    def test_percentile(self,):
        assert_array_equal(self.a.percentile(self.d, threshold=99.5), self.m)

    def test_iqr(self):
        assert_array_equal(self.a.iqr(self.d), self.m)

    def test_kde(self):
        assert_array_equal(self.a.kde(self.d), self.m)

    def test_z_score(self):
        assert_array_equal(self.a.z_score(self.d), self.m)

    def test_algos(self):
        for i, (n, f, t) in enumerate(self.a.algorithms):
            self.assertEqual(n, self.a.algorithms[i][0])
            if n == "Percentile Outliers":
                t = 99.5
            assert_array_equal(f(self.d, threshold=t), self.m)

    def test_datasets0(self):
        ds = DataSets1d()
        self.assertEqual(len(ds.datasets), 2)
        counter = 0
        for name, generator in ds.datasets.items():
            self.assertIn(name, ["lognormal-0.100_0.400:200_20","lognormal-0.500_0.400:200_20"])
            for a,b,c in generator:
                counter += 1
                self.assertEqual(len(b), 200)
                self.assertEqual(len(c), 200)
        self.assertEqual(counter, 2*1)

    def test_datasets1(self):
        ds = DataSets1d(window=100)
        counter = 0
        for name, generator in ds.datasets.items():
            self.assertIn(name, ["lognormal-0.100_0.400:200_20", "lognormal-0.500_0.400:200_20"])
            for a, b, c in generator:
                counter += 1
                self.assertEqual(len(b), 100)
                self.assertEqual(len(c), 100)
        self.assertEqual(counter, 2*101)

    def test_datasets2(self):
        ds = DataSets1d(window=100, skip=5)
        counter = 0
        for name, generator in ds.datasets.items():
            self.assertIn(name, ["lognormal-0.100_0.400:200_20", "lognormal-0.500_0.400:200_20"])
            for a, b, c in generator:
                counter += 1
                self.assertEqual(len(b), 100)
                self.assertEqual(len(c), 100)
        self.assertEqual(counter, 2*21)

    def test_dataset3(self):
        ds = DataSets1d(n=20, window=15, n_outliers=2, type='normal')
        counter = 0
        for name, generator in ds.datasets.items():
            self.assertIn(name, ["normal-0.100_0.400:20_2", "normal-0.500_0.400:20_2"])
            for a, b, c in generator:
                counter += 1
                self.assertEqual(len(b), 15)
                self.assertEqual(len(c), 15)
        self.assertEqual(counter, 2*6)

    def test_dataset4(self):
        ds = DataSets1d(n=20, window=15, n_outliers=2, type='uniform')
        counter = 0
        for name, generator in ds.datasets.items():
            self.assertIn(name, ["uniform-0.100_0.400:20_2", "uniform-0.500_0.400:20_2"])
            for a, b, c in generator:
                counter += 1
                self.assertEqual(len(b), 15)
                self.assertEqual(len(c), 15)
        self.assertEqual(counter, 2*6)

    def test_dataset5(self):
        ds = DataSets1d(n=20, window=None, skip=-1, n_outliers=2, type='uniform')
        counter = 0
        for name, generator in ds.datasets.items():
            self.assertIn(name, ["uniform-0.100_0.400:20_2", "uniform-0.500_0.400:20_2"])
            for a, b, c in generator:
                counter += 1
                self.assertEqual(len(b), 20)
                self.assertEqual(len(c), 20)
        self.assertEqual(counter, 2*1)

    def test_model_evaluation0(self):
        e = Outliers1dEvaluation()
        alg = Outliers1d()
        ds = DataSets1d(n=20, window=20, n_outliers=2, type='normal', outlier_range=(10,12))
        for name, generator in ds.datasets.items():
            for a, b, c in generator:
                r = e.model_metrics(2, b, c, alg.z_score)
                self.assertEqual((1.0, 1.0, 1.0, [[2, 0.0], [0.0, 18]]), r)
                r = e.model_metrics(20, b, c, alg.z_score)
                self.assertEqual((0, 0, 0, [[0, 2.0], [0.0, 18]]), r)

    def test_model_evaluation1(self):
        e = Outliers1dEvaluation()
        alg = Outliers1d()
        ds = DataSets1d(n=30, window=20, n_outliers=3, type='normal', outlier_range=(10,12))
        r = e.opt_score(3, ds, alg.z_score)
        self.assertTrue(-0.9<r and r<-0.0)

    def test_model_evalutation2(self):
        e = Outliers1dEvaluation()
        alg = Outliers1d()
        ds = DataSets1d(n=50, window=40, n_outliers=4, type='normal', outlier_range=(8, 10))
        nl = e.optimize_models(ds, alg)
        print(nl)

    def test_model_evalutation3(self):
        e = Outliers1dEvaluation()
        alg = Outliers1d()
        ds = DataSets1d(n=50, window=40, n_outliers=4, type='normal', outlier_range=(8, 10))
        nl = e.model_eval(ds, alg, include_data=True)
        self.assertEqual(len(nl), 2*5*11) # 2 data sets, 5 models, 11 windows

if __name__ == '__main__':
    unittest.main()
