import unittest
from amp_jaeger.jaeger_query import *

class TestJeagerQuery(unittest.TestCase):

    def test_Tag1(self):
        t = Tag({})
        self.assertEqual(str(t), '{}')

    def test_Tag2(self):
        t_dict = {
            'key': 1,
            'value': 2,
            'type': 3
        }
        t = Tag(t_dict)
        self.assertEqual(t.key, 1)
        self.assertEqual(t.value, 2)
        self.assertEqual(t.type, 3)

    def test_Tag3(self):
        t_dict = {
            'key': 1,
            'value': 2,
            'type': 3
        }
        t1 = Tag(t_dict)
        t2 = Tag(t_dict)
        self.assertTrue(t1 == t2)
        t1.type = "who cares"
        self.assertTrue(t1 != t2)
        t1.key = "nope"
        self.assertTrue(t1 != t2)

    def test_Reference1(self):
        r_dict =  {
            'refType': "CHILD_OF",
            'traceID': "a",
            'spanID': "b"
        }
        r = Reference(r_dict)
        self.assertEqual(r.refType, "CHILD_OF")
        self.assertEqual(r.traceID, "a")
        self.assertEqual(r.spanID, "b")
        self.assertEqual(r.factory_key(), 'a-b')

    def test_Process1(self):
        p_dict = {
            4: {
                'serviceName': 'test_service_name',
                'tags': [
                    {
                        'key': 1,
                        'value': 2,
                        'type': 3
                    }
                ]
            }
        }
        p = Process(4, p_dict[4])
        self.assertEqual(p(), 'test_service_name')
        self.assertEqual(p.tags_list[0], Tag({
            'key': 1,
            'value': 2,
            'type': 3
        }))
        t2 = Tag( {
                        'key': 1,
                        'value': 2,
                        'type': 3
                    })
        self.assertTrue(p.is_tag_match(t2))
        t2.type = "junk"
        self.assertFalse(p.is_tag_match(t2))

    def test_Span1(self):
        s = {
            'traceID': 1,
            'spanID': 2,
            'operationName': 3,
            'references': [],
            'startTime': 24343523454,
            'duration': 13423,
            'tags': [],
            'logs': [],
            'processID': 4,
            'warnings': None
        }
        p = {
            4: {
                'serviceName': 'test_service_name',
                'tags': []
            }
        }
        span = Span(s, p)

if __name__ == '__main__':
    unittest.main()
