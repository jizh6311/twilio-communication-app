import requests
import pandas as pd
import logging
from urllib.parse import urlencode
import datetime
import json
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt

logging.basicConfig(level=logging.DEBUG, filename="./amp_jaeger.log")

#########################################################
class Tag:

    def __init__(self, s):
        for k, v in s.items():
            setattr(self, k, v)
        if not set(['key','value','type']).issubset(self.__dict__.keys()):
            logging.warning("Invalid tag object, key(s) missing {}".format(s))

    def __eq__(self, ot):
        if self.key == ot.key and self.value == ot.value and self.type == ot.type:
            # any other added fields don't count for equality
            return True
        else:
            return False

    def __ne__(self, ot):
        return not self.__eq__(ot)

    def __repr__(self):
        return str(self.__dict__)


#########################################################
class Reference:

    def __init__(self, s):
        for k, v in s.items():
            setattr(self, k, v)
        if not set(['refType','traceID','SpanId']).issubset(self.__dict__.keys()):
            logging.warning("Invalid reference object, key(s) missing {}".format(s))

    def factory_key(self):
        return '-'.join([self.traceID, self.spanID])

    def __repr__(self):
        return str(self.__dict__)

#########################################################
class Process:

    def __init__(self, p_name, p_dict):
        self.name = p_name
        for k, v in p_dict.items():
            setattr(self, k, v)
        if not set(['serviceName', 'tags']).issubset(self.__dict__.keys()):
            logging.warning("Invalid process object, key(s) missing {}".format(s))

        self.tags_list = [Tag(x) for x in self.tags]

    def is_tag_match(self, tag):
        return any([i == tag for i in self.tags_list])

    def __call__(self):
        return self.serviceName

    def __repr__(self):
        return str(self.__dict__)

#########################################################
class Span:

    def __init__(self, s, p):
        self.span_dict = s
        for k, v in s.items():
            setattr(self, k, v)

        if not set([
            'traceID',
            'spanID',
            'operationName',
            'references',
            'startTime',
            'duration',
            'tags',
            'logs',
            'processID',
            'warnings'
        ]).issubset(self.__dict__.keys()):
            logging.warning("Invalid tag object, key(s) missing {}".format(s))

        # make a list of Tag objects
        self.tags_list = [Tag(i) for i in self.tags]
        # make a translation to service name for convenience
        self.process = p[self.processID]
        # datetime objects
        self.start_time_datetime = datetime.datetime.fromtimestamp(self.startTime/ 1e6)
        self.duration_timedelta = datetime.timedelta(seconds=self.duration/ 1e6)

    def is_tag_match(self, tag):
        return any([i == tag for i in self.tags_list])

    def get_row(self):
        return [self.operationName, self.process(), self.start_time_datetime, int(self.duration)]

    def factory_key(self):
        return '-'.join([self.traceID, self.spanID])

    def __repr__(self):
        res = """
        {} (spanID: {})
        -----------------------------------------
             traceID: {}
           startTime: {} ({} microsec)
            duration: {} s ({} microsec)
        Service Name: {}
        """.format(self.operationName,
                   self.spanID,
                   self.traceID,
                   self.start_time_datetime,
                   self.startTime,
                   self.duration_timedelta,
                   self.duration,
                   self.process())
        return res

#########################################################
class TraceQuery:


    def __init__(self, trace_id, config, save_file=None):
        self.config = config
        req_url = self.config["jeag_url"].format(trace_id)
        self._query(req_url, save_file)

    def _query(self, ru, save_file=None):
        logging.debug("request url={}".format(ru))
        d = requests.get(ru, auth=tuple(self.config["creds"]))
        self.result = d.json()['data']
        if save_file is not None:
            with open(save_file, "w") as ofile:
                json.dump(d.json(), ofile)
                logging.info("Writing json data to {}".format(save_file))
        logging.debug(self.result)
        self.process_map = {}
        self.factory = {}

    def __len__(self):
        # number of traces
        return len(self.result)

    def _get_spans(self):
        # generator of traces
        for x in self.result:
            self.process_map = {k: Process(k, v) for k,v in x["processes"].items()}
            for i in x["spans"]:
                s = Span(i, self.process_map)
                # allows references to rapidly look up spans
                self.factory[s.factory_key()] = s
                yield s

    def stats(self, alt_res=None):
        if alt_res is None:
            alt_res = list(self._get_spans())
        # stats by operationName and processID
        data = [s.get_row() for s in alt_res]
        df = pd.DataFrame(data, columns=['service', 'process', 'start_time', 'duration'])
        print(df[['service', 'process', 'duration']].groupby(['service', 'process']).describe())
        return df

    def hists(self, alt_res=None):
        if alt_res is None:
            alt_res = list(self._get_spans())
        df = self.stats(alt_res)
        print()
        for serv in list(df.service.unique()):
            for proc in list(df.process.unique()):
                print("service={} process={}".format(serv, proc))
                dft = df.loc[(df["service"] == serv) & (df['process'] == proc)]
                print(matplotlib.get_backend())
                dft.hist("duration", bins=100)
                plt.show()

    def select(self, spanID=None, operationName=None, tag=None, processID=None, serviceName=None):
        res = []
        for s in self._get_spans():
            if ((processID is not None and s.processID == processID)
                    or (serviceName is not None and s.process() == serviceName)
                    or (spanID is not None and s.spanID == spanID)
                    or (operationName is not None and s.operationName == operationName)
                    or (tag is not None and s.is_tag_match(tag))):
                res.append(s)
        return res

    def __repr__(self):
        res = ""
        for s in self._get_spans():
            res += "{}\n".format(s)
        return res

#########################################################
class ServiceQuery(TraceQuery):
    jea_url = "https://my.aspenmesh.io/client/jaeger-query/gauche-octopus/api/traces?{}"

    def __init__(self, serviceName, config, save_file=None):
        self.config = config
        _url = self.config["jeag_url"][:-3] + "?{}"
        req_url = _url.format(urlencode({"service": serviceName}))
        self._query(req_url, save_file)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Command line Jaeger Query')
    parser.add_argument('--tid', help="query using trace id")
    parser.add_argument('--file', default=None, help="save raw json to output filepath")
    parser.add_argument('--stats', default=False, action='store_true', help="calculate stats")
    args = parser.parse_args()
    trace = TraceQuery(args.tid, args.file)
    print(trace)
    if args.stats:
        print(trace.stats())