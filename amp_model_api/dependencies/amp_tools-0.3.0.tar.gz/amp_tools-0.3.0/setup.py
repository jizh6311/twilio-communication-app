from distutils.core import setup

setup(
    name='amp_tools',
    version='0.3.0',
    packages=['amp_jaeger', 'amp_prometheus', 'amp_outliers'],
    license='Aspen Mesh'
)
